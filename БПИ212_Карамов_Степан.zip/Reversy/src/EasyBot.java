// Здесь я везде передаю table, потому что, как я понял, передается объект по ссылке,
// а сама ссылка по значению (как написано в интернете). Если не так, прошу поправить))
public class EasyBot implements Player {
    public final Color PIECE_COLOR;
    public final Color ENEMY_PIECE_COLOR;

    public EasyBot(Color pieceColor) {
        PIECE_COLOR = pieceColor;
        ENEMY_PIECE_COLOR = PIECE_COLOR == Color.BLACK ? Color.WHITE : Color.BLACK;
    }

    @Override
    public boolean play(Table table) {
        // Здесь очень много раз повторяются одни и те же циклы, тк я обращаюсь не напрямую к tableArray, а через
        // методы: здесь это не страшно по скорости, но я просто не понимаю (и надеюсь, Вы мне ответите), как можно
        // сделать перечисляемый объект (к которому можно применить квадратные скобки), чтобы при этом его нельзя
        // было изменять? В шарпе были Enumerable, в плюсах можно было перегрузить [], а тут что? Я не нашел, надеюсь,
        // простительно :)
        if (!table.isAnyPossibleTurn()) {
            System.out.print(StringConstants.NO_POSSIBLE_TURNS);
            return false;
        }
        System.out.print(StringConstants.ENTER_TURN);

        int maxValue = -1;
        int turnRow = -1;
        int turnColumn = -1;
        for (var i = 0; i < table.TABLE_WIDTH; ++i) {
            for (var j = 0; j < table.TABLE_WIDTH; ++j) {
                if (!table.isTurnPossible(i, j)) {
                    continue;
                }
                int value = getFunctionValue(i, j, table);
                if (maxValue < value) {
                    maxValue = value;
                    turnRow = i;
                    turnColumn = j;
                }
            }
        }

        table.updateTable(turnRow, turnColumn, PIECE_COLOR);
        return true;
    }

    public int getFunctionValue(int row, int column, Table table) {
        int function = 0;
        int shift;
        // Да, этот кусок кода написан 2 раза, я понимаю, но я долго думал, как переделать так, чтобы сильно не
        // изменять структру, но не использовать два раза одно и то же - не придумал, слишком поздно начал делать и
        // не совсем правильную структуру программы выбрал
        for (var i = -1; i < 2; ++i) {
            for (var j = -1; j < 2; ++j) {
                for (shift = 1;
                     column + shift * j < table.TABLE_WIDTH && column + shift * j >= 0 &&
                             row + shift * i < table.TABLE_WIDTH && row + shift * i >= 0 &&
                             table.tableArray[row + shift * i][column + shift * j] == ENEMY_PIECE_COLOR;
                     ++shift) { }
                if (column + shift * j < table.TABLE_WIDTH && column + shift * j >= 0 &&
                        row + shift * i < table.TABLE_WIDTH && row + shift * i >= 0 && shift > 1 &&
                        table.tableArray[row + shift * i][column + shift * j] == PIECE_COLOR) {
                    while (shift > 1) {
                        --shift;
                        int pieceRow = row + shift * i;
                        int pieceColumn = row + shift * j;
                        if (pieceRow == 0 || pieceRow == table.TABLE_WIDTH - 1 || pieceColumn == 0 || pieceColumn == table.TABLE_WIDTH - 1) {
                            function += 2;
                        } else {
                            function += 1;
                        }
                    }
                }
            }
        }
        if (row == 0 || row == table.TABLE_WIDTH - 1 || column == 0 || column == table.TABLE_WIDTH - 1) {
            function += 0.4;
            if (row + column == 0 || row + column == table.TABLE_WIDTH - 1 || row + column == 2*table.TABLE_WIDTH - 2) {
                function += 0.4;
            }
        }
        return function;
    }
}
