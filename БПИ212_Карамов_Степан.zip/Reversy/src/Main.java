import java.util.HashSet;

public class Main {
    public static void main(String[] args) {
        Session session = new Session();
        session.start();
    }
}