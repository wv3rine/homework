public class Game {
    private LivePlayer player1;
    private Player player2;
    private Table table;

    Game(LivePlayer player1, Player player2) {
        this.player1 = player1;
        this.player2 = player2;
        table = new Table();
    }

    void run() {
        boolean firstPlayerHasTurn = true;
        boolean secondPlayerHasTurn = true;
        while (firstPlayerHasTurn && secondPlayerHasTurn) {
            table.print();
            firstPlayerHasTurn = player1.play(table);
            table.print();
            secondPlayerHasTurn = player2.play(table);
        }

        int score = 0;
        for (Color[] row : table.tableArray) {
            for (Color cell : row) {
                if (cell == player1.PIECE_COLOR) {
                    ++score;
                }
            }
        }
        System.out.print(StringConstants.SCORE + score);
        player1.trySetScore(score);
    }
}
