enum Color {
    EMPTY,
    WHITE,
    BLACK,
    POSSIBLE_TURN
}