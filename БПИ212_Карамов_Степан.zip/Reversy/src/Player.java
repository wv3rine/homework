public interface Player {
    boolean play(Table table);
}
