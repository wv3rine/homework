import java.util.HashSet;

public class Table {
    public final int TABLE_WIDTH = 8;
    Color[][] tableArray = new Color[TABLE_WIDTH][TABLE_WIDTH];
    private HashSet<int[]> possibleTurns;
    private Color currentPlayerColor = Color.BLACK;
    Table() {
        tableInitialization();
    }

    void tableInitialization() {
        for (var i = 0; i < TABLE_WIDTH; ++i) {
            for (var j = 0; j < TABLE_WIDTH; ++j) {
                tableArray[i][j] = Color.EMPTY;
            }
        }
        tableArray[TABLE_WIDTH/2 - 1][TABLE_WIDTH/2 - 1] = Color.WHITE;
        tableArray[TABLE_WIDTH/2][TABLE_WIDTH/2] = Color.WHITE;
        tableArray[TABLE_WIDTH/2 - 1][TABLE_WIDTH/2] = Color.BLACK;
        tableArray[TABLE_WIDTH/2][TABLE_WIDTH/2 - 1] = Color.BLACK;
        calculatePossibleTurns(currentPlayerColor);
    }

    // Обновляет таблицу с ходом (правильным) в клетку {row, column} игроком цвета color:
    // 1) ставит фишку, обновляет таблицу согласно правилам
    // 2) обновляет possibleTurns и добавляет в таблицу соответствующие Color
    // 3) обновляет currentPlayerColor
    // Здесь довольно много логики в одном методе, но я закомментировал куски - нужно ли в таком случае дробить
    // на методы поменьше? Кажется, так органичнее
    void updateTable(int row, int column, Color color) {
        Color enemyColor = color == Color.BLACK ? Color.WHITE : Color.BLACK;
        tableArray[row][column] = color;
        int shift;

        // Очистка таблицы. На всякий случай не через possible_turn, так кажется проще
        for (var i = 0; i < TABLE_WIDTH; ++i) {
            for (var j = 0; j < TABLE_WIDTH; ++j) {
                if (tableArray[i][j] == Color.POSSIBLE_TURN) {
                    tableArray[i][j] = Color.EMPTY;
                }
            }
        }

        // это универсальная штука вместо 8 разных циклов
        for (var i = -1; i < 2; ++i) {
            for (var j = -1; j < 2; ++j) {
                // Пока каждая последующая фишка противоположного цвета, продвигаемся до фишки
                // нашего цвета или до конца таблицы.
                for (shift = 1;
                     column + shift*j < TABLE_WIDTH && column + shift*j >= 0 &&
                             row + shift*i < TABLE_WIDTH && row + shift*i >= 0 &&
                             tableArray[row + shift*i][column + shift*j] == enemyColor;
                     ++shift) { }
                if (column + shift*j < TABLE_WIDTH && column + shift*j >= 0 &&
                        row + shift*i < TABLE_WIDTH && row + shift*i >= 0 && shift > 1 &&
                        tableArray[row + shift*i][column + shift*j] == color) {
                    while (shift > 1) {
                        --shift;
                        tableArray[row + shift*i][column + shift*j] = color;
                    }
                }
            }
        }

        currentPlayerColor = enemyColor;
        calculatePossibleTurns(currentPlayerColor);
    }

    HashSet<int[]> calculatePossibleTurns(Color color) {
        Color enemyColor = color == Color.BLACK ? Color.WHITE : Color.BLACK;
        possibleTurns = new HashSet<>();
        int shift;
        for (int row = 0; row < TABLE_WIDTH; ++row) {
            for (int column = 0; column < TABLE_WIDTH; ++column) {
                if (tableArray[row][column] != color) {
                    continue;
                }
                for (var i = -1; i < 2; ++i) {
                    for (var j = -1; j < 2; ++j) {
                        // Пока каждая последующая фишка противоположного цвета, продвигаемся до фишки
                        // нашего цвета, до пустого места или до конца таблицы.
                        for (shift = 1;
                             column + shift*j < TABLE_WIDTH && column + shift*j >= 0 &&
                                     row + shift*i < TABLE_WIDTH && row + shift*i >= 0 &&
                                     tableArray[row + shift*i][column + shift*j] == enemyColor;
                             ++shift) { }
                        if (column + shift*j < TABLE_WIDTH && column + shift*j >= 0 &&
                                row + shift*i < TABLE_WIDTH && row + shift*i >= 0 && shift > 1 &&
                                tableArray[row + shift*i][column + shift*j] == Color.EMPTY) {
                            possibleTurns.add(new int[]{row + shift*i, column + shift*j});
                        }
                    }
                }
            }
        }

        for (int[] possibleTurn : possibleTurns) {
            tableArray[possibleTurn[0]][possibleTurn[1]] = Color.POSSIBLE_TURN;
        }

        return possibleTurns;
    }

    void print() {
        System.out.print(StringConstants.TABLE_SIGNS);
        for (var j = -1; j < TABLE_WIDTH; ++j) {
            if (j == -1) {
                System.out.print("\\\t");
                continue;
            }
            System.out.print(j + "\t");
        }
        System.out.println();

        for (var i = 0; i < TABLE_WIDTH; ++i) {
            for (var j = -1; j < TABLE_WIDTH; ++j) {
                if (j == -1) {
                    System.out.print(i + "\t");
                    continue;
                }

                switch (tableArray[i][j]) {
                    case EMPTY -> System.out.print(".\t");
                    case WHITE -> System.out.print("W\t");
                    case BLACK -> System.out.print("B\t");
                    case POSSIBLE_TURN -> System.out.print("o\t");
                }
            }
            System.out.println();
        }

        printPossibleTurns();
    }

    void printPossibleTurns() {
        System.out.print(StringConstants.POSSIBLE_TURNS);
        for (int[] possibleTurn : possibleTurns) {
            System.out.print("{" + possibleTurn[0] + "; " + possibleTurn[1] + "} ");
        }
        System.out.println();
    }

    boolean isTurnPossible(int x, int y) {
        for (int[] possibleTurn : possibleTurns) {
            if (possibleTurn[0] == x && possibleTurn[1] == y) {
                return true;
            }
        }
        return false;
    }

    boolean isAnyPossibleTurn() {
        return !possibleTurns.isEmpty();
    }
}
