import java.util.Scanner;

public class Session {
    private Mode mode;
    private LivePlayer player1 = new LivePlayer(Color.BLACK);
    private LivePlayer player2 = new LivePlayer(Color.WHITE);
    private HardBot hardBot = new HardBot(Color.WHITE);
    private EasyBot easyBot = new EasyBot(Color.WHITE);
    private Game game;

    void start() {
        do {
            mainMenu();

            switch (mode) {
                case PLAYER_VS_PLAYER -> game = new Game(player1, player2);
                case PLAYER_VS_EASY_BOT -> game = new Game(player1, easyBot);
                case PLAYER_VS_HARD_BOT -> game = new Game(player1, hardBot);
            }

            game.run();
        } while (!isEnd());
    }

    /*
    Печатает в консоль главное меню (откуда можно выбрать режим и посмотреть max_score) и обрабатывает эти запросы
    */
    void mainMenu() {
        int command_code;
        do {
            // Можно тут сделать очистку
            System.out.print(StringConstants.MODE_CHOICE);
            command_code = ConsoleHandler.inputNumberInPositiveRange(1, 3);
            if (command_code == 3) {
                System.out.print(StringConstants.SHOW_MAX_SCORE);
                System.out.print(player1.getMaxScore());
                command_code = -1;
            }
        } while (command_code == -1);

        switch (command_code) {
            case 1 -> mode = Mode.PLAYER_VS_PLAYER;
            case 2 -> mode = Mode.PLAYER_VS_EASY_BOT;
        }
    }

    boolean isEnd() {
        int command_code;
        do {
            System.out.print(StringConstants.END);
            command_code = ConsoleHandler.inputNumberInPositiveRange(0, 1);
        } while (command_code == -1);

        return command_code == 0;
    }

    static class ConsoleHandler {
        /*
        Возвращает неотрицательное число, введенное с консоли, если оно из диапазона [left, right] (left и right тоже
        неотрицательны), -1 иначе (тут возникают странные константы, но мне показалось это не очень плохим решением для
        первой работы: дальше постараюсь лучше :)
        */
        static int inputNumberInPositiveRange(int left, int right) {
            Scanner scannerIn = new Scanner(System.in);
            if (!scannerIn.hasNextInt()) {
                return -1;
            }
            int number = scannerIn.nextInt();
            if (number < left || number > right) {
                return -1;
            }
            return number;
        }

        static int[] inputTwoNumbers() {
            Scanner scannerIn = new Scanner(System.in);
            if (!scannerIn.hasNextInt()) {
                return null;
            }
            int number1 = scannerIn.nextInt();
            if (!scannerIn.hasNextInt()) {
                return null;
            }
            int number2 = scannerIn.nextInt();
            return new int[] {number1, number2};
        }
        static void clear() {
            for (var i = 0; i < 25; ++i) {
                System.out.println();
            }
        }
    }
}
