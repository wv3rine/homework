public class LivePlayer implements Player {
    public final Color PIECE_COLOR;
    public final Color ENEMY_PIECE_COLOR;
    private int maxScore = 0;

    public LivePlayer(Color pieceColor) {
        PIECE_COLOR = pieceColor;
        ENEMY_PIECE_COLOR = PIECE_COLOR == Color.BLACK ? Color.WHITE : Color.BLACK;
    }

    @Override
    public boolean play(Table table) {
        if (!table.isAnyPossibleTurn()) {
            System.out.print(StringConstants.NO_POSSIBLE_TURNS);
            return false;
        }
        System.out.print(StringConstants.ENTER_TURN);

        int[] turn = Session.ConsoleHandler.inputTwoNumbers();
        while (turn != null && !table.isTurnPossible(turn[0], turn[1])) {
            System.out.print(StringConstants.ERROR);
            turn = Session.ConsoleHandler.inputTwoNumbers();
        }

        table.updateTable(turn[0], turn[1], PIECE_COLOR);
        return true;
    }

    public int getMaxScore() {
        return maxScore;
    }

    public boolean trySetScore(int score) {
        if (maxScore > score) {
            return false;
        }
        maxScore = score;
        return true;
    }
}
