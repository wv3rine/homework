// Хотел бы узнать, насколько вообще правильно делать класс для констант и какие есть аналоги?
// Хочу просто, чтобы они были отдельно и не засоряли код
final public class StringConstants {
    public static final String MODE_CHOICE = """

            Введите 1, если хотите играть в режиме "Игрок против игрока";
            2, в режиме "Игрок против легкого бота";
            3, если хотите вывести свое максимальное количество очков
            """;
    public static final String ERROR = "\nОшибка! Повторите ввод: ";
    public static final String END = "\nИгра окончена! Введите 1, если хотите продолжить, 0 иначе:\n";
    public static final String POSSIBLE_TURNS = "\nВозможные ходы:\n";
    public static final String NO_POSSIBLE_TURNS = "\nВозможных ходов нет, управление передается следующему игроку.\n";
    public static final String ENTER_TURN = "\nВведите ваш ход (два числа - координата по вертикали и по горизонтали):\n";
    public static final String SHOW_MAX_SCORE = "\nВаше максимальное количество очков (у первого игрока) - ";
    public static final String TABLE_SIGNS = "\nW - белые, B - черные, . - незанятые, o - которые можно занять\n";
    public static final String SCORE = "\nСчет первого игрока:\n";

}
