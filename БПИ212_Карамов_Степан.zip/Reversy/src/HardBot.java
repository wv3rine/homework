public class HardBot implements Player {
    public final Color PIECE_COLOR;
    public final Color ENEMY_PIECE_COLOR;

    public HardBot(Color pieceColor) {
        PIECE_COLOR = pieceColor;
        ENEMY_PIECE_COLOR = PIECE_COLOR == Color.BLACK ? Color.WHITE : Color.BLACK;
    }

    @Override
    public boolean play(Table table) {
        return true;
    }
}
